def fooFunc():
    print("Printing from the fooFunc, in the fooFile module, in the my_package package ")