from .fooFile import fooFunc
from .vehicles import Car, ElectricCar
from .shops import Restaurant, IceCreamStand